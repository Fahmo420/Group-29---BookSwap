using ConsoleApp1.Models;

namespace BookSwap.Models;

public class Student : Användare
{
    public List<Annons> EgnaAnnonser { get; set; } = new();
    public List<Affär> Köp { get; set; } = new();
}

