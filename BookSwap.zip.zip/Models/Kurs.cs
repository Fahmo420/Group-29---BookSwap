namespace BookSwap.Models;

public class Kurs
{
    public string Kod { get; set; } = "";
    public string Namn { get; set; } = "";
}