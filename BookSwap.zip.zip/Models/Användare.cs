﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Models
{
    public abstract class Användare
    {
        public int Id { get; set; }
        public string Förnamn { get; set; } = "";
        public string Efternamn { get; set; } = "";
        public string Epost { get; set; } = "";
        public string Telefon { get; set; } = "";
        public string Lösenord { get; set; } = "";


    }
}
